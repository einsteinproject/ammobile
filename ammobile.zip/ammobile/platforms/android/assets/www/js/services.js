angular.module('starter.services', [])

.factory('Emails', function () {
  var emails = [
    { id: 0, from: 'Scruff McGruff', to: 'Olivia Cui', subject: 'Alert UI Confirm', sent: '10/02/2014 11:21:26 PM' },
    { id: 1, from: 'G.I. Joe', to: 'Erick Sun', subject: "Check out Tony Liu's new photo", sent: '10/12/2014 11:21:26 PM' },
    { id: 2, from: 'Miss Frizzle', to: 'Ray Li', subject: 'All Dell Inc. 的每日 Chatter 摘要', sent: '10/22/2014 11:21:26 PM' },
    { id: 3, from: 'Scruff McGruff', to: 'Olivia Cui', subject: 'Toad for MySQL Weekly Digest', sent: '10/12/2014 11:21:26 PM' },
    { id: 4, from: 'G.I. Joe', to: 'Erick Sun', subject: 'Toad for SQL Server Weekly Digest', sent: '10/12/2014 11:21:26 PM' },
    { id: 5, from: 'Miss Frizzle', to: 'Olivia', subject: '您的 Chatter 的每日摘要' },
    { id: 6, from: 'Ash Ketchum', to: 'Erick Sun', subject: 'RE: Planned Maintenance - Melbourne office power - Sat 6/12/14 - 6:00 am to 8:00 pm AEDT', sent: '10/22/2014 11:21:26 PM' }
  ];

  return {
    all: function (searchData) {
      if (searchData.searchData === "1")
        return emails;
      else {
        var filtered = [];
        for (var i = 0; i < 3; i++) {
          filtered.push(emails[i]);
        }
        return filtered;
      }
    },
    get: function (id) {
      return emails[id];
    }
  };
});
