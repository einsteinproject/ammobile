angular.module('starter.controllers', [])

.controller('AppCtrl', function ($scope, $ionicModal, $timeout) {
  // Form data for the login modal
  $scope.loginData = {};

  $scope.loginMessage = "You have not login Archive Manager";

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function (modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function () {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function () {
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function () {

    $scope.loginMessage = "Logged in as " + $scope.loginData.userName;

    console.log('Doing login', $scope.loginData);

    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function () {
      $scope.closeLogin();
    }, 1000);
  };
})

.controller('SavedSearchCtrl', function ($scope, $location) {

  $scope.searchData = {result:"2"};

  $scope.savedSearches = [
    { title: 'saved search 1', id: 1 },
    { title: 'saved search 2', id: 2 },
    { title: 'saved search 3', id: 3 },
  ];

  $scope.searchData.savedSearch = $scope.savedSearches[0];

  $scope.doSearch = function () {
    $location.url('/app/search/' + $scope.searchData.result);
  };
})

.controller('SearchCtrl', function ($scope, $location) {

  $scope.searchData = {result:"1"};

  $scope.mailboxes = [
    { title: 'All', id: 0 },
    { title: 'Ray Li', id: 1 },
    { title: 'Erick Sun', id: 2 },
    { title: 'Olivia Cui', id: 3 },
  ];

  $scope.searchData.subject = true;

  $scope.searchData.body = true;

  $scope.searchData.mailbox = $scope.mailboxes[0];

  $scope.doSearch = function () {
    $location.url('/app/search/'+ $scope.searchData.result);
  };
})

.controller('SearchResultCtrl', function ($scope, $stateParams, Emails) {
  $scope.emails = Emails.all($stateParams);
})

.controller('EmailDetailCtrl', function ($scope, $stateParams, Emails) {
  $scope.email = Emails.get($stateParams.id);
});
